import os
import re
import uuid
from pathlib import Path

import cv2
import numpy as np
from flask import Flask, render_template, request, url_for
from paddleocr import PaddleOCR
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "static" / "uploads"
RESULT_DIR = BASE_DIR / "static" / "results"
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp", "bmp"}
MAX_FILE_SIZE = 12 * 1024 * 1024

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
RESULT_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_FILE_SIZE

# PaddleOCR 3.x API. The first run downloads the pretrained OCR model.
# This is pretrained OCR inference; it does not train a custom VIN model.
ocr = PaddleOCR(
    lang="en",
    use_doc_orientation_classify=False,
    use_doc_unwarping=False,
    use_textline_orientation=False,
    device="cpu",
)

VIN_PATTERN = re.compile(r"[A-HJ-NPR-Z0-9]{17}")
# OCR often confuses these pairs. We do NOT auto-correct them because that
# could silently create the wrong vehicle identifier.
VIN_CONFUSABLES = set("0ODQ1IL8B5S2Z")


def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def preprocess_image(image_path: Path, output_path: Path):
    """Load image, enlarge small images, and make a contrast-enhanced variant."""
    image = cv2.imread(str(image_path))
    if image is None:
        raise ValueError("The uploaded file could not be read as an image.")

    height, width = image.shape[:2]
    # Enlarge small images to help text recognition, while limiting huge images.
    scale = 2.0 if max(height, width) < 1400 else 1.0
    if scale != 1.0:
        image = cv2.resize(image, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)

    if max(image.shape[:2]) > 2400:
        scale = 2400 / max(image.shape[:2])
        image = cv2.resize(image, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(gray)
    enhanced_bgr = cv2.cvtColor(enhanced, cv2.COLOR_GRAY2BGR)

    if not cv2.imwrite(str(output_path), enhanced_bgr):
        raise ValueError("Could not save the processed image.")
    return image, enhanced_bgr


def unpack_paddle_result(result_items):
    """Extract text and confidence from PaddleOCR 3.x result objects."""
    found = []
    for item in result_items or []:
        data = None
        try:
            # PaddleOCR 3.x result objects commonly support dictionary access.
            data = item.get("res", item) if hasattr(item, "get") else None
        except Exception:
            data = None

        if data is None:
            try:
                data = item.json.get("res", item.json)
            except Exception:
                data = {}

        texts = data.get("rec_texts", []) if isinstance(data, dict) else []
        scores = data.get("rec_scores", []) if isinstance(data, dict) else []
        boxes = data.get("rec_boxes", []) if isinstance(data, dict) else []

        for i, text in enumerate(texts):
            score = float(scores[i]) if i < len(scores) else 0.0
            box = []
            if i < len(boxes):
                try:
                    box = np.asarray(boxes[i]).astype(float).tolist()
                except Exception:
                    box = []
            cleaned = str(text).strip()
            if cleaned:
                found.append({"text": cleaned, "confidence": round(score, 4), "box": box})
    return found


def find_vin_candidates(text_items):
    """Search recognized text for exact 17-character standard VIN candidates."""
    candidates = []
    for item in text_items:
        raw = item["text"].upper()
        # Remove spaces and punctuation, but do not invent/replace characters.
        compact = re.sub(r"[^A-Z0-9]", "", raw)
        # Search every possible 17-character window, useful if OCR adds a prefix.
        for match in re.finditer(r"[A-Z0-9]{17}", compact):
            candidate = match.group(0)
            valid_chars = bool(VIN_PATTERN.fullmatch(candidate))
            candidates.append({
                "vin": candidate,
                "confidence": item["confidence"],
                "valid_standard_characters": valid_chars,
                "source_text": raw,
            })

    # Keep unique candidates, preferring higher OCR confidence.
    best = {}
    for candidate in candidates:
        key = candidate["vin"]
        if key not in best or candidate["confidence"] > best[key]["confidence"]:
            best[key] = candidate
    return sorted(best.values(), key=lambda x: x["confidence"], reverse=True)


def run_ocr(image_path: Path):
    # Run on original and enhanced image; combine results and keep unique text.
    enhanced_path = RESULT_DIR / f"{image_path.stem}_processed.png"
    _, enhanced_image = preprocess_image(image_path, enhanced_path)

    results_original = ocr.predict(str(image_path))
    results_enhanced = ocr.predict(enhanced_image)

    combined = unpack_paddle_result(results_original) + unpack_paddle_result(results_enhanced)

    unique = {}
    for item in combined:
        key = re.sub(r"\s+", "", item["text"]).upper()
        if key not in unique or item["confidence"] > unique[key]["confidence"]:
            unique[key] = item

    text_items = sorted(unique.values(), key=lambda x: x["confidence"], reverse=True)
    candidates = find_vin_candidates(text_items)
    chosen = candidates[0] if candidates else None

    if chosen:
        if not chosen["valid_standard_characters"]:
            status = "Candidate found, but it contains characters not allowed in a standard VIN."
        elif chosen["confidence"] < 0.75:
            status = "Low-confidence candidate. Please confirm every character manually."
        else:
            status = "Candidate found. Confirm it against the vehicle before saving."
    else:
        status = "No exact 17-character VIN candidate found. Try a clearer, closer, well-lit image."

    return {
        "text_items": text_items,
        "candidates": candidates,
        "chosen": chosen,
        "status": status,
        "processed_image": enhanced_path.name,
    }


@app.errorhandler(413)
def file_too_large(_error):
    return render_template("index.html", error="File is too large. Maximum upload size is 12 MB."), 413


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "GET":
        return render_template("index.html")

    upload = request.files.get("image")
    if not upload or not upload.filename:
        return render_template("index.html", error="Please select an image first.")

    safe_name = secure_filename(upload.filename)
    if not allowed_file(safe_name):
        return render_template("index.html", error="Unsupported file type. Use PNG, JPG, JPEG, WEBP or BMP.")

    unique_id = uuid.uuid4().hex[:12]
    extension = Path(safe_name).suffix.lower()
    saved_name = f"{unique_id}{extension}"
    saved_path = UPLOAD_DIR / saved_name
    upload.save(saved_path)

    try:
        result = run_ocr(saved_path)
    except Exception as exc:
        app.logger.exception("OCR failed")
        return render_template(
            "index.html",
            error=f"OCR failed: {exc}. Check the terminal for details and confirm the dependencies installed correctly.",
            original_image=url_for("static", filename=f"uploads/{saved_name}"),
        )

    return render_template(
        "index.html",
        original_image=url_for("static", filename=f"uploads/{saved_name}"),
        processed_image=url_for("static", filename=f"results/{result['processed_image']}"),
        result=result,
    )


if __name__ == "__main__":
    # Accessible from your local network for phone testing. Do not expose this
    # development server directly to the public internet.
    app.run(host="0.0.0.0", port=5000, debug=True)

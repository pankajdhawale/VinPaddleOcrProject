# VIN Scanner with PaddleOCR + OpenCV + Flask

A starter web app that uploads an image, preprocesses it, runs pretrained PaddleOCR, and searches the recognized text for 17-character VIN candidates.

## Requirements

- Ubuntu/Linux
- Python 3.9 or newer (Python 3.10 is a practical choice)
- Internet connection for installing packages and downloading pretrained OCR models on first run

## 1. Create a virtual environment

```bash
cd ~/Downloads/vin_paddleocr_project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
```

## 2. Install PaddlePaddle CPU runtime and project dependencies

PaddleOCR 3.x requires a compatible inference engine. For a CPU-only Ubuntu setup, follow the official PaddlePaddle CPU installation instructions. One documented installation command is:

```bash
python -m pip install paddlepaddle==3.2.0 -i https://www.paddlepaddle.org.cn/packages/stable/cpu/
python -m pip install -r requirements.txt
```

If installation fails due to your Python version or package compatibility, use the official PaddleOCR installation page to choose the matching PaddlePaddle wheel:
https://www.paddleocr.ai/main/en/version3.x/installation.html

## 3. Run the app

```bash
python app.py
```

Open this on the same computer:

http://127.0.0.1:5000

The first OCR run may download pretrained model files. Keep the terminal open while the server runs.

## 4. Test from an Android phone on the same Wi-Fi

Find the computer's LAN IP:

```bash
hostname -I
```

Then open `http://YOUR_COMPUTER_IP:5000` on the phone. The phone and computer must be on the same Wi-Fi, and the firewall must allow local port 5000. Do not expose Flask's development server directly to the public internet.

## 5. Test with a command line image

The browser is the easiest way to test. To test an image via HTTP after starting the app:

```bash
curl -F "image=@/absolute/path/to/vin-image.jpg" http://127.0.0.1:5000/
```

This endpoint returns HTML, not JSON. For Android integration, add a dedicated `/api/scan` route that returns JSON and secure it before deployment.

## How it works

- `app.py`: Flask upload route, OpenCV preprocessing, PaddleOCR inference, candidate extraction.
- `templates/index.html`: upload UI and results.
- `static/uploads/`: uploaded images.
- `static/results/`: preprocessed images.

## Important accuracy notes

- A standard VIN is 17 characters and excludes I, O and Q.
- Not every country or vehicle identifier follows the same assumptions. Verify the applicable VIN standard for your target market.
- This starter does not train a custom model and does not guarantee exact VIN accuracy.
- OCR confidence is not the probability that the complete VIN is correct.
- Do not automatically change `O` to `0`, `I` to `1`, or similar characters. Ask the user to verify uncertain characters.
- The example image supplied with the project appears to show an 18-character string, so it should not be treated as a verified standard VIN ground truth.
- For better performance, collect labelled VIN plate images, evaluate exact-match accuracy on a held-out set, and consider a plate detector or fine-tuned recognition model if needed.
